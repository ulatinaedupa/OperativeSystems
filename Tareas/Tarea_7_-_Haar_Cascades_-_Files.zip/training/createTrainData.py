#!/usr/bin/python
import os
import sys
import random
import subprocess

cmd = "./createsamples -bgcolor 0 -bgthresh 0 -maxxangle 1.1 -maxyangle 1.1 maxzangle 0.5 -maxidev 40 -w 20 -h 20"
numSamples = 7000

if len(sys.argv) < 2:
  print("Usage: python createTrainData.py\n"
        "  <positives_collection_filename>\n"
        "  <negatives_collection_filename>\n"
        "  <output_dirname>\n"
        "  [<totalnum = " + numSamples + ">]\n"
        "  [<createsample_command_options = '" + cmd + "'>]\n")
  sys.exit()

posFilepath = sys.argv[1]
negFilepath = sys.argv[2]
outputDir = sys.argv[3]
numSamples = int(sys.argv[4])
cmd = sys.argv[5]

# read positive and negative txt files
with open(posFilepath) as f:
  posFiles = [x.strip() for x in f.readlines()]
with open(negFilepath) as g:
  negFiles = [x.strip() for x in g.readlines()]

# total number of positive images
numPosFiles = len(posFiles)
# number of samples per positive image
numSamplesPerImage = int(numSamples / numPosFiles)
# if numSamples = 15 and numPosFiles = 4, numRemainSamples = 3
numRemainSamples = numSamples - numSamplesPerImage * numPosFiles

# loop over all positive images
for i, posFile in enumerate(posFiles):
  print("{} Processing: {}".format('='*50, posFile))
  # Ideally number of samples should always be greater than number of positive examples
  # In case you pick numSamples < numPosFiles, this loop should break after
  # generating numSamples samples
  if i >= numSamples:
    break

  # add 1 to numSamplesThisImage for the first numRemainSamples images
  # so the final count would be
  # numRemainSamples*(numSamplesPerImage+1) + (numPosFiles - numRemainSamples)*(numSamplesPerImage) = numSamples
  if i < numRemainSamples:
    numSamplesThisImage = numSamplesPerImage + 1
  else:
    numSamplesThisImage = numSamplesPerImage

  # open_createsamples uses a file which contains path to negative images as value to argument -bg
  # so we will write the randomly sampled negative file path to a temp file
  negFile = random.sample(negFiles, 1)[0]
  with open('tmpNeg.txt', 'w') as g:
    g.write(negFile + '\n')

  if os.path.isfile(posFile) and os.path.isfile(negFile):
    # .vec file in which augmented samples for an image will be stored
    vecFile = os.path.join(outputDir, os.path.splitext(os.path.basename(posFile))[0] + '.vec')
    # construct the command which will be run on terminal/command prompt
    cmdFull = '{} -img {} -bg {} -vec {} -num {} '.format(cmd, posFile, 'tmpNeg.txt', vecFile, numSamplesThisImage)
    # print full command
    print('{} running command: '.format('='*30))
    print(cmdFull)
    # run it
    process = subprocess.Popen(cmdFull.split(), stdout=subprocess.PIPE)
    output, error = process.communicate()
    print('{} Output from opencv_createsamples {}'.format('='*30, '='*30))
    print(output.decode('utf-8'))
    if error:
      print('{} Error from opencv_createsamples {}'.format('='*30, '='*30))
      print(error)
    print('='*90 + '\n')

# python createTrainData.py positives.txt negatives.txt samples 70 "opencv_createsamples -bgcolor 0 -bgthresh 0 -maxxangle 1.1 -maxyangle 1.1 maxzangle 0.5 -maxidev 40 -w 30 -h 30"