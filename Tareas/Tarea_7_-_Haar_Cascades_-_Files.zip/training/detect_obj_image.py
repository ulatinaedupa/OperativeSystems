# import the necessary packages
import cv2
import imutils
import argparse as ap

ap = argparse.ArgumentParser()
ap.add_argument("-i", "--image", required=True, help="Path to the image to analyze")
args = vars(ap.parse_args())

image = cv2.imread(args["image"])

obj_det = cv2.CascadeClassifier('haar/cascade.xml') # load object model
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)  # convert it to grayscale

obj_rec = obj_det.detectMultiScale(gray, scaleFactor = 1.15, minNeighbors = 3, minSize = (15, 15)) # detect object
    
for (x, y, w, h) in obj_rec: # for every rectangle found
    cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2) # draw the first rectangle

cv2.imshow("Window", image)
key = cv2.waitKey(0)
cv2.destroyAllWindows()