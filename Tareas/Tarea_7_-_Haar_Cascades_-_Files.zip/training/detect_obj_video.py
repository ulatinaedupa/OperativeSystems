import cv2
import imutils

obj_det = cv2.CascadeClassifier('haar/cascade.xml') # load object model

camera = cv2.VideoCapture(0)

while True:
	# grab the current frame
    (grabbed, frame) = camera.read()
    if not grabbed:
        break
    frame = imutils.resize(frame, width = 300)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)  # convert it to grayscale

    obj_rec = obj_det.detectMultiScale(gray, scaleFactor = 1.15, minNeighbors = 3, minSize = (15, 15)) # detect object
    
    # keep looping
    for (x, y, w, h) in obj_rec: # for every rectangle found
	    cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2) # draw the first rectangle
    key = cv2.waitKey(1)
    if key == 0x1B or key == ord("q"): 
	    break
    cv2.imshow("Window", frame)
camera.release() # cleanup the camera
cv2.destroyAllWindows() # close windows









