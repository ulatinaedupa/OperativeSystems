import os


def printdir(dirname):
  paths = os.listdir(dirname)
  with open(dirname + ".txt","w") as f:
    for fname in paths:
      f.write(dirname + '/' + fname + '\n')


POSITIVES_DIR = "positives"
printdir(POSITIVES_DIR)
NEGATIVES_DIR = "negatives"
printdir(NEGATIVES_DIR)